import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Matrix {

	private final int[][] matrix;

	public Matrix(int knoten) {
		matrix = new int[knoten][knoten];
	}

	public Matrix(Matrix m) {
		matrix = new int[m.length()][m.length()];

		for (int row = 0; row < m.length(); row++) {
			for (int col = 0; col < m.length(); col++) {
				matrix[row][col] = m.matrix[row][col];
			}
		}
	}

	public int csvLength(String pfad) {
		String zeile;
		String[] zeilenSep;
		int count = 0;

		try (BufferedReader br = new BufferedReader(new FileReader(pfad))) {
			zeile = br.readLine();
			zeilenSep = zeile.trim().split(";");

			count = zeilenSep.length;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return count;
	}

	public Matrix(String pfad) {
		int importLength = csvLength(pfad);
		matrix = new int[importLength][importLength];

		for (int row = 0; row < importLength; row++) {
			for (int col = 0; col < importLength; col++) {
				matrix[row][col] = readCSV(pfad).matrix[row][col];
			}
		}
	}


	public void setValues(int row, int col, int value) {
		matrix[row][col] = value;
		matrix[col][row] = value;
	}

	public int[][] getMatrix() {
		return matrix;
	}

	public void setDiagonale(int value) {
		for (int i = 0; i < length(); i++) {
			matrix[i][i] = value;
		}
	}

	public void setInfinite() {
		for (int row = 0; row < matrix.length; row++) {
			for (int col = 0; col < matrix.length; col++) {
				if (matrix[row][col] == 0 && row != col) {
					setValues(row, col, -99);
				}
			}
		}
	}

	public int length() {
		return matrix.length;
	}

	public Matrix readCSV(String pfad) {
		String zeile;
		String[] zeilenSep;
		Matrix importedMatrix = new Matrix(csvLength(pfad));

		try (BufferedReader br = new BufferedReader(new FileReader(pfad))) {
			zeile = br.readLine();
			int row = 0;
			while (zeile != null) {
				zeilenSep = zeile.trim().split(";");

				for (int i = 0; i < zeilenSep.length; i++) {
					importedMatrix.matrix[row][i] = Integer.parseInt(zeilenSep[i]);
				}
				row++;
				zeile = br.readLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return importedMatrix;
	}

	public Matrix multiply(Matrix mobject) {
		Matrix product = new Matrix(length());

		for (int row = 0; row < length(); row++) {
			for (int col = 0; col < length(); col++) {
				for (int i = 0; i < length(); i++) {
					product.matrix[row][col] += matrix[row][i] * mobject.matrix[i][col];
				}
			}
		}
		return product;
	}

	public Matrix potenz(int potenz) {
		Matrix pmatrix = new Matrix(this);

		for (int i = 1; i < potenz; i++) {
			pmatrix = pmatrix.multiply(this);
		}
		return pmatrix;
	}

	public void print() {
		for (int[] row : matrix) {
			for (int col : row) {
				if (col == -99) {
					System.out.print("∞ ");
				} else {
					System.out.print(col + " ");
				}
			}
			System.out.println();
		}
	}
}
