import java.util.ArrayList;
import java.util.Iterator;

public class Graph {
        private Matrix matrix;

        public Graph(Matrix matrix) {
                this.matrix = matrix;
        }


        public static Graph fromMatrix(Matrix matrix) {
                return new Graph(matrix);
        }

        public Matrix distanzmatrix() {
                Matrix dmatrix = new Matrix(matrix);
                dmatrix.setInfinite();

                for (int potenz = 2; potenz < dmatrix.length(); potenz++) {
                        Matrix pmatrix = matrix.potenz(potenz);
                        for (int row = 0; row < dmatrix.length(); row++) {
                                for (int col = 0; col < dmatrix.length(); col++) {
                                        if (row != col && pmatrix.getMatrix()[row][col] > 0 && dmatrix.getMatrix()[row][col] == -99) {
                                                dmatrix.setValues(row, col, potenz);
                                        }
                                }
                        }
                }
                return dmatrix;
        }

        public int[] exzentrizitaeten() {
                int[] exz = new int[matrix.length()];
                Matrix dmatrix = distanzmatrix();
                for (int row = 0; row < matrix.length(); row++) {
                        for (int col = 0; col < matrix.length(); col++) {
                                exz[row] = Math.max(dmatrix.getMatrix()[row][col], exz[row]);
                        }
                }
                return exz;
        }

        public int radius() {
                int[] exz = exzentrizitaeten();
                int radius = exz[0];
                for (int i = 0; i < exz.length; i++) {
                        radius = Math.min(exz[i], radius);
                }

                Graph zwischen = Graph.fromMatrix(matrix);
                if(zwischen.komponenten().size() > 1)
                        return -1;
                return radius;

        }

        public int durchmesser() {
                int[] exz = exzentrizitaeten();
                int durchmesser = exz[0];
                for (int i = 0; i < exz.length; i++) {
                        durchmesser = Math.max(exz[i], durchmesser);
                }
                Graph zwischen = Graph.fromMatrix(matrix);
                if(zwischen.komponenten().size() > 1)
                        return -1;
                return durchmesser;
        }

        public ArrayList<Integer> zentrum() {
                int[] exz = exzentrizitaeten();
                int radius = radius();
                ArrayList<Integer> zentrum = new ArrayList<>();

                for (int i = 0; i < exz.length; i++) {
                        if (exz[i] == radius) {
                                zentrum.add(i + 1);
                        }
                }
                return zentrum;
        }

        public Matrix wegmatrix() {
                Matrix wmatrix = new Matrix(matrix);
                wmatrix.setDiagonale(1);
                for (int potenz = 2; potenz < wmatrix.length(); potenz++) {
                        Matrix pmatrix = matrix.potenz(potenz);
                        for (int row = 0; row < wmatrix.length(); row++) {
                                for (int col = 0; col < wmatrix.length(); col++) {
                                        if (row != col && wmatrix.getMatrix()[row][col] == 0 && pmatrix.getMatrix()[row][col] != 0) {
                                                wmatrix.setValues(row, col, 1);
                                        }
                                }
                        }
                }
                return wmatrix;
        }

        public ArrayList<ArrayList<Integer>> komponenten() {
                Matrix wmatrix = new Matrix(this.wegmatrix());
                ArrayList<ArrayList<Integer>> komponenten = new ArrayList<>();

                for (int row = 0; row < wmatrix.length(); row++) {
                        ArrayList<Integer> sepkomponente = new ArrayList<>();
                        for (int col = 0; col < wmatrix.length(); col++) {
                                if(wmatrix.getMatrix()[row][col] == 1) {
                                        sepkomponente.add(col + 1);
                                }
                        }
                        boolean added = true;
                        Iterator<ArrayList<Integer>> iter = komponenten.iterator();
                        while(iter.hasNext()) {
                                ArrayList<Integer> komponente = iter.next();

                                if(komponente.equals(sepkomponente)) {
                                        added = false;
                                        break;
                                }
                        }
                        if(added) {
                                komponenten.add(sepkomponente);
                        }
                }
                return komponenten;
        }

        public ArrayList<Integer> artikulationen(){
                int komponentenanzahl = komponenten().size();
                ArrayList<Integer> artikulationen = new ArrayList<>();

                for(int aktknoten = 0; aktknoten < matrix.length(); aktknoten++) {
                        Matrix checkmatrix = new Matrix(matrix);

                        for(int i = 0; i < checkmatrix.length(); i++) {
                                checkmatrix.getMatrix()[aktknoten][i] = 0;
                                checkmatrix.getMatrix()[i][aktknoten] = 0;
                        }
                        Graph zwischen = Graph.fromMatrix(checkmatrix);
                        ArrayList<ArrayList<Integer>> comparekomponenten = zwischen.komponenten();
                        if(comparekomponenten.size() -1 > komponentenanzahl) {
                                artikulationen.add(aktknoten + 1);
                        }
                }
                return artikulationen;
        }

        public ArrayList<ArrayList<Integer>> bruecken() {
                ArrayList<ArrayList<Integer>> bruecken = new ArrayList<>();
                int komponentenanzahl = komponenten().size();

                for (int row = 0; row < matrix.length(); row++) {
                        for (int col = row + 1; col < matrix.length(); col++) {
                                if (matrix.getMatrix()[row][col] == 1) {
                                        Matrix checkmatrix = new Matrix(matrix);
                                        checkmatrix.setValues(row, col, 0);
                                        checkmatrix.setValues(col, row, 0);
                                        Graph tempGraph = new Graph(checkmatrix);
                                        int modifiedKomponentenAnzahl = tempGraph.komponenten().size();

                                        if (modifiedKomponentenAnzahl > komponentenanzahl) {
                                                ArrayList<Integer> bruecke = new ArrayList<>();
                                                bruecke.add(Math.min(row + 1, col + 1));
                                                bruecke.add(Math.max(row + 1, col + 1));
                                                if (!bruecken.contains(bruecke)) {
                                                        bruecken.add(bruecke);
                                                }
                                        }
                                }
                        }
                }
                return bruecken;
        }

}
