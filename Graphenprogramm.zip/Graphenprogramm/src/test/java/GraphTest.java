    import org.junit.jupiter.api.Test;
    import java.util.ArrayList;
    import java.util.List;


    class GraphTest {

        @Test
        void test1() {
            String pfad = "src/main/resources/24n_01.csv";

            Matrix matrix = new Matrix(pfad);

            System.out.println("Eingelesene Matrix:");
            matrix.print();


            Graph graph = new Graph(matrix);
            System.out.println("Distanzmatrix:");
            Matrix dmatrix = graph.distanzmatrix();
            dmatrix.print();

            int[] exzentrizitaeten = graph.exzentrizitaeten();
            System.out.println("Exzentrizitäten:");
            for (int exzentrität : exzentrizitaeten) {
                System.out.print(exzentrität + " ");
            }
            System.out.println();

            int durchmesser = graph.durchmesser();
            int radius = graph.radius();
            List<Integer> zentrum = graph.zentrum();
            System.out.println("Durchmesser des Graphen: " + durchmesser);
            System.out.println("Radius des Graphen: " + radius);
            System.out.print("Zentrum des Graphen: ");
            zentrum.forEach(knoten -> System.out.print(knoten + " "));
            System.out.println();

            ArrayList<ArrayList<Integer>> komponenten = graph.komponenten();
            System.out.println("Komponenten des Graphen:");
            komponenten.forEach(komponente -> {
                komponente.forEach(knoten -> System.out.print(knoten + " "));
                System.out.println();
            });

            ArrayList<Integer> artikulationen = graph.artikulationen();
            System.out.println("Artikulationen des Graphen:");
            artikulationen.forEach(System.out::println);

            ArrayList<ArrayList<Integer>> bruecken = graph.bruecken();
            System.out.println("Brücken des Graphen:");
            bruecken.forEach(bruecke -> {
                bruecke.forEach(knoten -> System.out.print(knoten + " "));
                System.out.println();
            });
        }

        @Test
        void test2() {
            String pfad = "src/main/resources/24n_01-nichtZusammenhängend.csv";

            Matrix matrix = new Matrix(pfad);

            System.out.println("Eingelesene Matrix:");
            matrix.print();


            Graph graph = new Graph(matrix);
            System.out.println("Distanzmatrix:");
            Matrix dmatrix = graph.distanzmatrix();
            dmatrix.print();

            int[] exzentrizitaeten = graph.exzentrizitaeten();
            System.out.println("Exzentrizitäten:");
            for (int exzentrität : exzentrizitaeten) {
                System.out.print(exzentrität + " ");
            }
            System.out.println();

            int durchmesser = graph.durchmesser();
            int radius = graph.radius();
            List<Integer> zentrum = graph.zentrum();
            System.out.println("Durchmesser des Graphen: " + durchmesser);
            System.out.println("Radius des Graphen: " + radius);
            System.out.print("Zentrum des Graphen: ");
            zentrum.forEach(knoten -> System.out.print(knoten + " "));
            System.out.println();

            ArrayList<ArrayList<Integer>> komponenten = graph.komponenten();
            System.out.println("Komponenten des Graphen:");
            komponenten.forEach(komponente -> {
                komponente.forEach(knoten -> System.out.print(knoten + " "));
                System.out.println();
            });

            ArrayList<Integer> artikulationen = graph.artikulationen();
            System.out.println("Artikulationen des Graphen:");
            artikulationen.forEach(System.out::println);

            ArrayList<ArrayList<Integer>> bruecken = graph.bruecken();
            System.out.println("Brücken des Graphen:");
            bruecken.forEach(bruecke -> {
                bruecke.forEach(knoten -> System.out.print(knoten + " "));
                System.out.println();
            });
        }
    }
